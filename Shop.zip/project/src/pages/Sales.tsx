import React, { useState, useEffect } from 'react';
import { Printer, Plus, Trash2, Save } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Product, Invoice, InvoiceItem } from '../types';

function Sales() {
  const [products, setProducts] = useState<Product[]>([]);
  const [company, setCompany] = useState<any>(null);
  const [currentInvoice, setCurrentInvoice] = useState<Partial<Invoice> & { items: InvoiceItem[] }>({
    invoice_number: `INV-${new Date().getTime()}`,
    transaction_date: new Date().toISOString(),
    total_amount: 0,
    payment_amount: 0,
    change_amount: 0,
    items: []
  });

  useEffect(() => {
    loadCompanyAndProducts();
  }, []);

  async function loadCompanyAndProducts() {
    const { data: userData } = await supabase.auth.getUser();
    if (userData.user) {
      const { data: userDetails } = await supabase
        .from('users')
        .select('company_id')
        .eq('id', userData.user.id)
        .single();

      if (userDetails) {
        const { data: companyData } = await supabase
          .from('companies')
          .select('*')
          .eq('id', userDetails.company_id)
          .single();

        const { data: productsData } = await supabase
          .from('products')
          .select('*')
          .eq('company_id', userDetails.company_id);

        if (companyData) setCompany(companyData);
        if (productsData) setProducts(productsData);
      }
    }
  }

  const addItem = () => {
    if (products.length === 0) return;
    
    const firstProduct = products[0];
    setCurrentInvoice(prev => ({
      ...prev,
      items: [...prev.items, {
        id: crypto.randomUUID(),
        invoice_id: '',
        product_id: firstProduct.id,
        quantity: 1,
        price: firstProduct.price,
        total: firstProduct.price,
        created_at: new Date().toISOString(),
        product: firstProduct
      }]
    }));
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: string | number) => {
    setCurrentInvoice(prev => ({
      ...prev,
      items: prev.items.map(item => {
        if (item.id === id) {
          if (field === 'product_id') {
            const product = products.find(p => p.id === value);
            if (product) {
              const quantity = item.quantity;
              const price = product.price;
              return {
                ...item,
                product_id: product.id,
                price: price,
                total: quantity * price,
                product
              };
            }
          } else if (field === 'quantity') {
            const quantity = Number(value);
            return {
              ...item,
              quantity,
              total: quantity * item.price
            };
          }
          return { ...item, [field]: value };
        }
        return item;
      })
    }));
  };

  const removeItem = (id: string) => {
    setCurrentInvoice(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const calculateTotal = () => {
    return currentInvoice.items.reduce((sum, item) => sum + item.total, 0);
  };

  const handlePaymentChange = (amount: number) => {
    const total = calculateTotal();
    setCurrentInvoice(prev => ({
      ...prev,
      payment_amount: amount,
      change_amount: amount - total
    }));
  };

  const saveInvoice = async () => {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user || !company) return;

    const total = calculateTotal();
    const invoiceData = {
      company_id: company.id,
      cashier_id: userData.user.id,
      invoice_number: currentInvoice.invoice_number,
      transaction_date: currentInvoice.transaction_date,
      total_amount: total,
      payment_amount: currentInvoice.payment_amount,
      change_amount: currentInvoice.change_amount
    };

    const { data: invoice, error: invoiceError } = await supabase
      .from('invoices')
      .insert(invoiceData)
      .select()
      .single();

    if (invoiceError || !invoice) {
      console.error('Error saving invoice:', invoiceError);
      return;
    }

    const invoiceItems = currentInvoice.items.map(item => ({
      invoice_id: invoice.id,
      product_id: item.product_id,
      quantity: item.quantity,
      price: item.price,
      total: item.total
    }));

    const { error: itemsError } = await supabase
      .from('invoice_items')
      .insert(invoiceItems);

    if (itemsError) {
      console.error('Error saving invoice items:', itemsError);
      return;
    }

    // Reset form
    setCurrentInvoice({
      invoice_number: `INV-${new Date().getTime()}`,
      transaction_date: new Date().toISOString(),
      total_amount: 0,
      payment_amount: 0,
      change_amount: 0,
      items: []
    });
  };

  const printInvoice = () => {
    window.print();
  };

  const ReceiptView = () => (
    <div className="text-sm print-receipt">
      <div className="text-center mb-4">
        {company?.logo_url && (
          <img
            src={company.logo_url}
            alt={company.name}
            className="h-12 mx-auto mb-2"
          />
        )}
        <h1 className="font-bold text-lg">{company?.name || 'Nota Penjualan'}</h1>
        <p className="text-xs">{currentInvoice.invoice_number}</p>
        <p className="text-xs">{new Date(currentInvoice.transaction_date).toLocaleDateString('id-ID')}</p>
        {company?.address && <p className="text-xs mt-1">{company.address}</p>}
        {company?.phone && <p className="text-xs">{company.phone}</p>}
      </div>

      <div className="border-t border-b border-black py-2 my-2">
        {currentInvoice.items.map((item) => (
          <div key={item.id} className="mb-2">
            <div className="flex justify-between">
              <span className="font-semibold">{item.product?.name}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span>{item.quantity} x {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(item.price)}</span>
              <span>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(item.total)}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-1 text-sm">
        <div className="flex justify-between">
          <span>Total:</span>
          <span>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(calculateTotal())}</span>
        </div>
        <div className="flex justify-between">
          <span>Tunai:</span>
          <span>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(currentInvoice.payment_amount)}</span>
        </div>
        <div className="flex justify-between font-bold">
          <span>Kembali:</span>
          <span>{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(currentInvoice.change_amount)}</span>
        </div>
      </div>

      <div className="text-center text-xs mt-4">
        <p>Terima kasih atas kunjungan Anda</p>
        <p>Simpan nota ini sebagai bukti pembayaran</p>
        {company?.email && <p className="mt-1">{company.email}</p>}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      {/* Editor Section - Hidden when printing */}
      <div className="print-hidden">
        <div className="bg-white shadow-lg rounded-lg p-6 mb-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Nota Penjualan</h1>
            <div className="flex justify-between items-center">
              <div>
                <p className="text-gray-600">Nomor: {currentInvoice.invoice_number}</p>
                <input
                  type="datetime-local"
                  value={currentInvoice.transaction_date.split('.')[0]}
                  onChange={(e) => setCurrentInvoice(prev => ({
                    ...prev,
                    transaction_date: e.target.value
                  }))}
                  className="mt-1 block rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="mb-6">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-300">
                  <th className="text-left py-2">Nama Barang</th>
                  <th className="text-right py-2">Jumlah</th>
                  <th className="text-right py-2">Harga</th>
                  <th className="text-right py-2">Total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {currentInvoice.items.map((item) => (
                  <tr key={item.id} className="border-b border-gray-200">
                    <td className="py-2">
                      <select
                        value={item.product_id}
                        onChange={(e) => updateItem(item.id, 'product_id', e.target.value)}
                        className="w-full border-0 focus:ring-0 bg-transparent"
                      >
                        {products.map(product => (
                          <option key={product.id} value={product.id}>
                            {product.name}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="py-2">
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                        className="w-20 text-right border-0 focus:ring-0"
                        min="1"
                      />
                    </td>
                    <td className="py-2 text-right">
                      {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(item.price)}
                    </td>
                    <td className="py-2 text-right">
                      {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(item.total)}
                    </td>
                    <td className="py-2">
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <button
              onClick={addItem}
              className="mt-4 flex items-center text-blue-600 hover:text-blue-800"
            >
              <Plus size={18} className="mr-1" /> Tambah Barang
            </button>
          </div>

          <div className="border-t-2 border-gray-300 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Total:</span>
                  <span className="text-xl font-bold">
                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(calculateTotal())}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Tunai:</span>
                  <input
                    type="number"
                    value={currentInvoice.payment_amount}
                    onChange={(e) => handlePaymentChange(Number(e.target.value))}
                    className="w-32 text-right border rounded-md"
                    min="0"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Kembali:</span>
                  <span className="text-xl font-bold">
                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(currentInvoice.change_amount)}
                  </span>
                </div>
              </div>
              <div className="flex justify-end items-end space-x-4">
                <button
                  onClick={saveInvoice}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center"
                  disabled={currentInvoice.items.length === 0}
                >
                  <Save size={18} className="mr-1" /> Simpan
                </button>
                <button
                  onClick={printInvoice}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
                  disabled={currentInvoice.items.length === 0}
                >
                  <Printer size={18} className="mr-1" /> Cetak
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Receipt Preview */}
        <div className="mb-6">
          <h2 className="text-xl font-bold mb-4">Preview Nota (58mm)</h2>
          <div className="receipt-preview rounded-lg">
            <ReceiptView />
          </div>
        </div>
      </div>

      {/* Print Layout - Only visible when printing */}
      <div className="hidden print:block print-receipt">
        <ReceiptView />
      </div>
    </div>
  );
}

export default Sales;