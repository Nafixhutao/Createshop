import React, { useState, useEffect } from 'react';
import { Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import * as XLSX from 'xlsx';

function Reports() {
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  const [salesData, setSalesData] = useState([]);
  const [summary, setSummary] = useState({
    totalSales: 0,
    totalTransactions: 0,
    averageTransaction: 0
  });
  const [topProducts, setTopProducts] = useState([]);

  useEffect(() => {
    loadReportData();
  }, [dateRange]);

  async function loadReportData() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;

    const { data: userDetails } = await supabase
      .from('users')
      .select('company_id')
      .eq('id', userData.user.id)
      .single();

    if (!userDetails) return;

    // Get sales data
    const { data: sales } = await supabase
      .from('invoices')
      .select(`
        *,
        items:invoice_items(
          *,
          product:products(*)
        )
      `)
      .eq('company_id', userDetails.company_id)
      .gte('transaction_date', dateRange.start)
      .lte('transaction_date', dateRange.end)
      .order('transaction_date', { ascending: false });

    if (sales) {
      setSalesData(sales);

      // Calculate summary
      const totalSales = sales.reduce((sum, invoice) => sum + invoice.total_amount, 0);
      setSummary({
        totalSales,
        totalTransactions: sales.length,
        averageTransaction: sales.length > 0 ? totalSales / sales.length : 0
      });

      // Calculate top products
      const productSales = {};
      sales.forEach(invoice => {
        invoice.items.forEach(item => {
          const productId = item.product.id;
          if (!productSales[productId]) {
            productSales[productId] = {
              name: item.product.name,
              quantity: 0,
              total: 0
            };
          }
          productSales[productId].quantity += item.quantity;
          productSales[productId].total += item.total;
        });
      });

      const topProductsList = Object.values(productSales)
        .sort((a, b) => b.total - a.total)
        .slice(0, 5);

      setTopProducts(topProductsList);
    }
  }

  const exportToExcel = () => {
    // Prepare data for export
    const exportData = salesData.map(invoice => ({
      'Nomor Nota': invoice.invoice_number,
      'Tanggal': new Date(invoice.transaction_date).toLocaleDateString('id-ID'),
      'Total': invoice.total_amount,
      'Pembayaran': invoice.payment_amount,
      'Kembalian': invoice.change_amount
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Laporan Penjualan');
    XLSX.writeFile(wb, `laporan-penjualan-${dateRange.start}-${dateRange.end}.xlsx`);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Laporan Penjualan</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <span>-</span>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={exportToExcel}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center"
          >
            <Download size={18} className="mr-1" /> Export Excel
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-600 mb-2">Total Penjualan</h2>
          <p className="text-3xl font-bold">
            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(summary.totalSales)}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-600 mb-2">Jumlah Transaksi</h2>
          <p className="text-3xl font-bold">{summary.totalTransactions}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-600 mb-2">Rata-rata Transaksi</h2>
          <p className="text-3xl font-bold">
            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(summary.averageTransaction)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Produk Terlaris</h2>
          <div className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={index} className="flex justify-between items-center">
                <div>
                  <p className="font-semibold">{product.name}</p>
                  <p className="text-sm text-gray-600">Terjual: {product.quantity}</p>
                </div>
                <p className="font-bold">
                  {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(product.total)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nomor Nota
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tanggal
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Pembayaran
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Kembalian
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {salesData.map((invoice) => (
              <tr key={invoice.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  {invoice.invoice_number}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(invoice.transaction_date).toLocaleDateString('id-ID')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(invoice.total_amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(invoice.payment_amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(invoice.change_amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Reports;