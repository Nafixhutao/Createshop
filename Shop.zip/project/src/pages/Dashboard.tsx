import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { supabase } from '../lib/supabase';

function Dashboard() {
  const [salesData, setSalesData] = useState([]);
  const [totalSales, setTotalSales] = useState(0);
  const [todaySales, setTodaySales] = useState(0);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    const { data: userData } = await supabase.auth.getUser();
    if (userData.user) {
      const { data: userDetails } = await supabase
        .from('users')
        .select('company_id')
        .eq('id', userData.user.id)
        .single();

      if (userDetails) {
        // Get today's sales
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const { data: todaySalesData } = await supabase
          .from('invoices')
          .select('total_amount')
          .eq('company_id', userDetails.company_id)
          .gte('transaction_date', today.toISOString());

        // Calculate today's total
        const todayTotal = todaySalesData?.reduce((sum, invoice) => sum + invoice.total_amount, 0) || 0;
        setTodaySales(todayTotal);

        // Get last 7 days sales
        const last7Days = new Date();
        last7Days.setDate(last7Days.getDate() - 7);
        
        const { data: weekSalesData } = await supabase
          .from('invoices')
          .select('total_amount, transaction_date')
          .eq('company_id', userDetails.company_id)
          .gte('transaction_date', last7Days.toISOString())
          .order('transaction_date', { ascending: true });

        // Process data for chart
        const processedData = weekSalesData?.reduce((acc, invoice) => {
          const date = new Date(invoice.transaction_date).toLocaleDateString('id-ID', { weekday: 'short' });
          const existingDay = acc.find(d => d.date === date);
          
          if (existingDay) {
            existingDay.amount += invoice.total_amount;
          } else {
            acc.push({ date, amount: invoice.total_amount });
          }
          
          return acc;
        }, []) || [];

        setSalesData(processedData);
        setTotalSales(processedData.reduce((sum, day) => sum + day.amount, 0));
      }
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-600 mb-2">Penjualan Hari Ini</h2>
          <p className="text-3xl font-bold">
            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(todaySales)}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-600 mb-2">Total Penjualan (7 Hari)</h2>
          <p className="text-3xl font-bold">
            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalSales)}
          </p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-lg font-semibold mb-4">Grafik Penjualan 7 Hari Terakhir</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip 
                formatter={(value) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(value)}
              />
              <Bar dataKey="amount" fill="#4F46E5" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;