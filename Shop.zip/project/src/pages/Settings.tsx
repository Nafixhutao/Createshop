import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Company } from '../types';

function Settings() {
  const [company, setCompany] = useState<Partial<Company>>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadCompanyData();
  }, []);

  async function loadCompanyData() {
    const { data: userData } = await supabase.auth.getUser();
    if (userData.user) {
      const { data: userDetails } = await supabase
        .from('users')
        .select('company_id')
        .eq('id', userData.user.id)
        .single();

      if (userDetails) {
        const { data: companyData } = await supabase
          .from('companies')
          .select('*')
          .eq('id', userDetails.company_id)
          .single();

        if (companyData) {
          setCompany(companyData);
        }
      }
    }
    setIsLoading(false);
  }

  async function handleSave() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;

    const { data: userDetails } = await supabase
      .from('users')
      .select('company_id')
      .eq('id', userData.user.id)
      .single();

    if (!userDetails?.company_id) {
      // Create new company
      const { data: newCompany, error: createError } = await supabase
        .from('companies')
        .insert(company)
        .select()
        .single();

      if (!createError && newCompany) {
        // Update user with new company_id
        await supabase
          .from('users')
          .update({ company_id: newCompany.id })
          .eq('id', userData.user.id);

        setCompany(newCompany);
      }
    } else {
      // Update existing company
      const { data: updatedCompany } = await supabase
        .from('companies')
        .update(company)
        .eq('id', userDetails.company_id)
        .select()
        .single();

      if (updatedCompany) {
        setCompany(updatedCompany);
      }
    }
  }

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Pengaturan</h1>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Informasi Perusahaan</h2>
        
        <div className="space-y-4 max-w-xl">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nama Perusahaan
            </label>
            <input
              type="text"
              value={company.name || ''}
              onChange={(e) => setCompany(prev => ({ ...prev, name: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              URL Logo
            </label>
            <input
              type="text"
              value={company.logo_url || ''}
              onChange={(e) => setCompany(prev => ({ ...prev, logo_url: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
            {company.logo_url && (
              <div className="mt-2">
                <img
                  src={company.logo_url}
                  alt="Logo Preview"
                  className="h-20 object-contain"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Alamat
            </label>
            <textarea
              value={company.address || ''}
              onChange={(e) => setCompany(prev => ({ ...prev, address: e.target.value }))}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nomor Telepon
            </label>
            <input
              type="text"
              value={company.phone || ''}
              onChange={(e) => setCompany(prev => ({ ...prev, phone: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              value={company.email || ''}
              onChange={(e) => setCompany(prev => ({ ...prev, email: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div className="pt-4">
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Simpan Pengaturan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Settings;