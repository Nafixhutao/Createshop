import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { LayoutDashboard, Receipt, Package, BarChart3, Settings } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Sales from './pages/Sales';
import Products from './pages/Products';
import Reports from './pages/Reports';
import Settings from './pages/Settings';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50 flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-lg">
          <div className="p-4">
            <h1 className="text-2xl font-bold text-gray-800">POS System</h1>
          </div>
          <nav className="mt-4">
            <Link
              to="/"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100"
            >
              <LayoutDashboard className="w-5 h-5 mr-2" />
              Dashboard
            </Link>
            <Link
              to="/sales"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Receipt className="w-5 h-5 mr-2" />
              Penjualan
            </Link>
            <Link
              to="/products"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Package className="w-5 h-5 mr-2" />
              Produk
            </Link>
            <Link
              to="/reports"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100"
            >
              <BarChart3 className="w-5 h-5 mr-2" />
              Laporan
            </Link>
            <Link
              to="/settings"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Settings className="w-5 h-5 mr-2" />
              Pengaturan
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/sales" element={<Sales />} />
            <Route path="/products" element={<Products />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;